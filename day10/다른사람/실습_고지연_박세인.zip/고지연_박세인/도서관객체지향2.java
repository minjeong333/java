package 고지연_박세인;

import java.util.Scanner;

public class 도서관객체지향2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		도서관2 lib = new 도서관2();
		lib.출력하기();
		System.out.println();
		
		 System.out.print("대출할 책 이름 입력(단종애사 자몽살구클럽 나의완벽한장례식 모순 이방인) : ");
	     String book = sc.next();
	     System.out.println(lib.대출(book));
	     lib.출력하기();
	     System.out.println();
	     
	     System.out.print("대출할 책 이름 입력(단종애사 자몽살구클럽 나의완벽한장례식 모순 이방인) : ");
	     String book1 = sc.next();
	     System.out.println(lib.대출(book1));
	     lib.출력하기();
	     System.out.println();
	     
	     System.out.print("대출할 책 이름 입력(단종애사 자몽살구클럽 나의완벽한장례식 모순 이방인) : ");
	     String book2 = sc.next();
	     System.out.println(lib.대출(book2));
	     lib.출력하기();
	     System.out.println();
	     
	     System.out.print("반납할 책 이름 입력(단종애사 자몽살구클럽 나의완벽한장례식 모순 이방인) : ");
	     String book3 = sc.next();
	     System.out.println(lib.반납(book3));
	     lib.출력하기();
	     System.out.println();
	     
	}

}
