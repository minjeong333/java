package 고지연_박세인;

public class 도서관2 {

	private int 단종애사 = 10;
	private int 자몽살구클럽 = 10;
	private int 나의완벽한장례식 = 10;
	private int 모순 = 10;
	private int 이방인 = 10;
	private int 총수량 = 0;
	
	public void 출력하기() {
		System.out.println("<도서관 책 목록>");
		System.out.println("단종애사="+this.단종애사);
		System.out.println("자몽살구클럽="+this.자몽살구클럽);
		System.out.println("나의완벽한장례식="+this.나의완벽한장례식);
		System.out.println("모순="+this.모순);
		System.out.println("이방인="+this.이방인);
		System.out.println("총수량="+this.총수량);
	}
	
	public String 대출(String 책이름) {
		if(책이름.equals("단종애사")) {
			this.단종애사 -= 1;
		}
		else if(책이름.equals("자몽살구클럽")) {
			this.자몽살구클럽 -= 1;
		}
		else if(책이름.equals("나의완벽한장례식")) {
			this.나의완벽한장례식 -= 1;
		}
		else if(책이름.equals("모순")) {
			this.모순 -= 1;
		}
		else if(책이름.equals("이방인")) {
			this.이방인 -= 1;
		}
		else {
			return "없는 책입니다.";
		}
		this.총수량 = this.단종애사 + this.자몽살구클럽 + this.나의완벽한장례식 + this.모순 + this.이방인;
		
		return "책이 대출되었습니다.";
	}
	
	public String 반납(String 책이름) {
		
		if(책이름.equals("단종애사")) {
			this.단종애사 += 1;
		}
		else if(책이름.equals("자몽살구클럽")) {
			this.자몽살구클럽 += 1;
		}
		else if(책이름.equals("나의완벽한장례식")) {
			this.나의완벽한장례식 += 1;
		}
		else if(책이름.equals("모순")) {
			this.모순 += 1;
		}
		else if(책이름.equals("이방인")) {
			this.이방인 += 1;
		}
		else {
			return "없는 책입니다.";
		}
		this.총수량 = this.단종애사 + this.자몽살구클럽 + this.나의완벽한장례식 + this.모순 + this.이방인;
		
		return "책이 반납되었습니다";
	}
}


