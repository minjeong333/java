package javaprj.day09.자동차객체만들기;

public class 부품 {

	private String 부품이름;
	private int 부품수명;
	
//	public void 부품입력(String 부품이름, int 부품수명) {
//		this.부품이름 = 부품이름;
//		this.부품수명 = 부품수명;
//	}
	
	
	public 부품() {
		// TODO Auto-generated constructor stub
	}
	public 부품(String 부품이름, int 부품수명) {
		super();
		this.부품이름 = 부품이름;
		this.부품수명 = 부품수명;
	}



	//출력
	public void 부품출력() {
		System.out.println("부품 이름: " + 부품이름 + ", 수명: " + 부품수명);
		
	}
	public int 부품수명감소() {
		int rand = 1 + (int)(Math.random() * 3);
		this.부품수명 = this.부품수명 - rand;
		System.out.println(this.부품이름 + " " + rand + " 마모됨!");
		
		// 0 이하일 때 0으로 만들어줌
		if(this.부품수명 < 0) 부품수명 = 0;
		
		return this.부품수명;
	}
	
}
