package javaprj.day09.자동차객체만들기;

import java.util.Arrays;

public class 자동차 {
	
	private String 자동차이름;
	private String 자동차타입;
	private int 자동차무게;
	private 부품[] 부품들;
	
	public void 자동차입력(String 이름, String 타입, int kg, 부품[] 부품리스트) {
		this.자동차이름 = 이름;
		this.자동차타입 = 타입;
		this.자동차무게 = kg;
		this.부품들 = 부품리스트;
	}
	public void 자동차출력() {
		System.out.println("자동차명: " + this.자동차이름);
		System.out.println("자동차 타입: " + this.자동차타입);
		System.out.println("공차중량: " + this.자동차무게 + "kg");
		//System.out.println(Arrays.toString(this.부품들));
		for(int i = 0; i < 부품들.length; i++) {
			부품들[i].부품출력();
		}
		System.out.println();
	}
	
	public void 자동차이름출력() {
		System.out.println(this.자동차이름);
	}

	
	public int 랜덤부품마모() {
		int rand = (int)(Math.random() * 4);
		int result = this.부품들[rand].부품수명감소();
		return result;
		
	}

}
