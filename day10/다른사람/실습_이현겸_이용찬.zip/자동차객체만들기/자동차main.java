package javaprj.day09.자동차객체만들기;

import java.util.Arrays;
import java.util.Scanner;

public class 자동차main {
	
	public static void main(String[] args) {
		// 세 대의 자동차 정보를 입력 받고
		// 한 대가 고장날 때까지 년 단위로 실행하는 프로그램
		
		// 부품 입력
		부품[]  부품리스트1  = { new 부품("타이어", 11), new 부품("엔진", 20), new 부품("미션", 20), new 부품("스타트모터", 10)};
		부품[]  부품리스트2  = { new 부품("타이어", 12), new 부품("엔진", 20), new 부품("미션", 20), new 부품("스타트모터", 10)};
		부품[]  부품리스트3  = { new 부품("타이어", 10), new 부품("엔진", 25), new 부품("미션", 25), new 부품("스타트모터", 10)};


		
		// 자동차 입력
		자동차 자동차1 = new 자동차();
		자동차1.자동차입력("그랜져", "대형세단", 1700, 부품리스트1);
		
		자동차 자동차2 = new 자동차();
		자동차2.자동차입력("소나타", "중형세단", 1500, 부품리스트2);
		
		자동차 자동차3 = new 자동차();
		자동차3.자동차입력("카니발", "대형 MPV", 2200, 부품리스트3);
		
		// 자동차 출력
		자동차1.자동차출력();
		자동차2.자동차출력();
		자동차3.자동차출력();
		
		// 먼저 고장나는 자동차를 구하는 메서드
		자동차굴리기(자동차1, 자동차2, 자동차3);


	}

	private static void 자동차굴리기(자동차 자동차1, 자동차 자동차2, 자동차 자동차3) {
		Scanner sc = new Scanner(System.in);
		int yearsSum = 0;
		System.out.println("어떤 차가 먼저 고장 날지 봅시다.");
		loop: while(true) {
			System.out.println("차를 몇 년 운행할지 입력하세요.");
			int years = sc.nextInt();
			for(int i = 0; i < years; i++) {
				System.out.println((yearsSum) + "년째");
				자동차1.자동차이름출력();
				int result1 = 자동차1.랜덤부품마모();
				자동차1.자동차출력();

				자동차2.자동차이름출력();
				int result2 = 자동차2.랜덤부품마모();
				자동차2.자동차출력();
			
				자동차3.자동차이름출력();
				int result3 = 자동차3.랜덤부품마모();
				자동차3.자동차출력();
				
				if(result1 == 0) {
					System.out.println("그랜져가 먼저 고장났네요!");
					break loop;
				} else if(result2 == 0) {
					System.out.println("소나타가 먼저 고장났네요!");
					break loop;
				} else if(result3 == 0) {
					System.out.println("카니발이 먼저 고장났네요!");
					break loop;
				}
				yearsSum++;
			
			}
		System.out.print("추가로 ");
		
		}
	}

}
