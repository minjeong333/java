package javaprj.day12.오전오후실습;

public class 밴드 extends 아티스트 {
	
	String[] 멤버들;
	
	public 밴드(String 이름, String[] 멤버들) {
		super(이름);
		this.멤버들 = 멤버들;
	}
	
	@Override
	public void 일하기() {
		
		System.out.println("밴드는 공연을 하였다!");
	}
	
	public void 밴드멤버출력() {
		for(int i = 0; i < 멤버들.length; i++) {
			System.out.print(멤버들[i] + ", ");
		}
		System.out.println();
	}
	
}
