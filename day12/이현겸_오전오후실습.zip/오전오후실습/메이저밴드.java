package javaprj.day12.오전오후실습;

public class 메이저밴드 extends 밴드 {

	public 메이저밴드(String 이름, String[] 멤버들) {
		super(이름, 멤버들);

	}
	
	@Override
	public void 일하기() {
		System.out.println("큰 무대에서 멋지게 공연하였다!");
		
	}
	
	public void 장비구매() {
		System.out.println("장비를 구매하였다.");
	}
	
}
