package javaprj.day12.오전오후실습;

public class 아티스트 {

	String 이름;
	
	public 아티스트(String 이름) {
		this.이름 = 이름;
	}
	
	public void 일하기() {
		System.out.println("아티스트는 자신의 작업을 하였다");
	}

	public String get이름() {
		return 이름;
	}

	public void set이름(String 이름) {
		this.이름 = 이름;
	}
	
	
}
