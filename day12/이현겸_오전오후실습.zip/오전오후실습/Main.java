package javaprj.day12.오전오후실습;

public class Main {

	public static void main(String[] args) {
		
		// 메이저, 마이너 아티스트로 업캐스팅, 다운캐스팅, 다형성 알아보기
		
		
		// 업캐스팅하여 리스트에 넣어보기
		아티스트[] arr = new 아티스트[4];
		arr[0] = new 밴드("the1975", new String[]{"매티힐리", "맥도날드"} );
		arr[1] = new 메이저밴드("AC/DC", new String[] {"앵거스 영", "말콤 영"});
		arr[2] = new 마이너밴드("야발밴드", new String[] {"이현겸", "이재호"});
		arr[3] = new 화가("달리");
		
		
		// 밴드, 메이저밴드, 마이너밴드, 화가의 부모 클래스 아티스트의 메서드인 일하기() 메서드 실행하기
		일시키기(arr);
		
		
		// 다운캐스팅하여 밴드 객체만의 고유 메서드 밴드멤버출력() 실행하기
		밴드이면멤버출력(arr);
		
		
		// 다운캐스팅으로 자식 고유의 메서드 실행해보기
		((메이저밴드)arr[1]).장비구매();
		((마이너밴드)arr[2]).알바하기();
		
		
		// 잘못된 다운캐스팅 해보기
		
		아티스트 artist = new 아티스트("적재");
		화가 painter = (화가) artist;
		// 에러는 여기서 발생함
		
		// painter.일하기(); // 태생이 아티스트(부모)라서 절~대 화가(자식)로 다운캐스팅 될 수 없음!
		
		
		

	}

	private static void 밴드이면멤버출력(아티스트[] arr) {
		System.out.println("메이저 마이너 관계 없이, 밴드이면 멤버를 출력할게요~");
		for(int i = 0; i < 4; i++) {
			if(arr[i] instanceof 밴드) {
				System.out.print(arr[i].get이름() + "의 멤버: ");
				((밴드)arr[i]).밴드멤버출력();
			}
		}
		System.out.println();
	}

	private static void 일시키기(아티스트[] arr) {
		System.out.println("모두에게 일을 시켜볼게요~");
		for(int i = 0; i < arr.length; i++) {
			String 아티스트이름 = arr[i].get이름();
			System.out.print(아티스트이름 + " ");
			arr[i].일하기();
		}
		System.out.println();
	}

}
