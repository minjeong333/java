package javaprj.day12.오전오후실습;

public class 화가 extends 아티스트 {
	
	public 화가(String 이름) {
		super(이름);
	}
	
	@Override
	public void 일하기() {
		System.out.println("화가는 그림을 그렸다!");
	}
	
}
