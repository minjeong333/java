package javaprj.day12.오전오후실습;

public class 마이너밴드 extends 밴드 {
	

	
	public 마이너밴드(String 이름, String[] 멤버들) {
		super(이름, 멤버들);
	}

	@Override
	public void 일하기() {
		
		System.out.println("술집에서 작은 공연을 했다!");
		
	}
	
	public void 알바하기() {
		System.out.println("돈이 모자라 알바를 하였다...");
	}
	
}
