package javaprj.day05;

public class 실습1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 실습 )
//		1. 배열저장출력문제    (값 넣고  출력하기)
//		   1) 1차원배열 사용하기 -  일주일점심메뉴 또는 단어  

		
//      lunch	크기 만들고 값 나중에 넣음
//		lunch2	new 사용해서 값 바로 넣음
//		lunch3	new 생략한 간단한 방식
		
		//1
		String[] lunch = new String[5];
		
		lunch[0] = "국밥";
		lunch[1] = "햄버거";
		lunch[2] = "짜장면";
		lunch[3] = "스시";
		lunch[4] = "떡볶이";
		
		System.out.println("1번 방법");
		System.out.println(lunch[0]);
		System.out.println(lunch[1]);
		System.out.println(lunch[2]);
		System.out.println(lunch[3]);
		System.out.println(lunch[4]);
		
		//반복문으로
		for(int i = 0; i < lunch.length; i++) {
		    System.out.println(lunch[i]);
		}
		
		//2
		String[] lunch2 =  new String[] {"국밥", "햄버거", "짜장면", "스시", "떡볶이"};
		
		System.out.println("2번 방법");
		System.out.println(lunch2[0]);
		System.out.println(lunch2[1]);
		System.out.println(lunch2[2]);
		System.out.println(lunch2[3]);
		System.out.println(lunch2[4]);
		
		//반복문으로
		for(int i = 0; i < lunch2.length; i++) {
		    System.out.println(lunch2[i]);
		}
		
		//3
		String[] lunch3 = {"국밥", "햄버거", "짜장면", "스시", "떡볶이"};
		
		System.out.println("3번 방법");
		System.out.println(lunch3[0]);
		System.out.println(lunch3[1]);
		System.out.println(lunch3[2]);
		System.out.println(lunch3[3]);
		System.out.println(lunch3[4]);
		
		//반복문으로
		for(int i = 0; i < lunch3.length; i++) {
		    System.out.println(lunch3[i]);
		}
		
		
	}

}
