package javaprj.day05;

public class 실습3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 실습 )
//		1. 배열저장출력문제    (값 넣고  출력하기)
//		   3) 1차원 배열 사용하기 - 좋아하는 음식  5개 저장하고 출력하기

		String[] food = new String[5];
		
		food[0] = "젤리";
		food[1] = "커피";
		food[2] = "케이크";
		food[3] = "훠궈";
		food[4] = "에그타르트";
		
		System.out.println(food[0]);
		System.out.println(food[1]);
		System.out.println(food[2]);
		System.out.println(food[3]);
		System.out.println(food[4]);
		
		//반복문으로
		for(int i = 0; i < food.length; i++) {
		    System.out.println(food[i]);
		}
		
	}

}
