package javaprj.day05;

public class 실습5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 실습 )
//		1. 배열저장출력문제    (값 넣고  출력하기)
//		   5) 3차원배열 사용하기
		
		String[][][] Word2 = {
				
				{
					{"apple", "book", "cat", "dog", "egg"},
					{"fish", "game", "home", "ice", "juice"},
					{"key", "lion", "moon", "name", "orange"},
					{"pen", "queen", "rain", "sun", "tree"}
					
				},
				
				{
					{"apple", "book", "cat", "dog", "egg"},
					{"fish", "game", "home", "ice", "juice"},
					{"key", "lion", "moon", "name", "orange"},
					{"pen", "queen", "rain", "sun", "tree"}
				}
				
			};
		
		//1면 cat
		System.out.println(Word2[0][0][2]);
		
		//2면 dog
		System.out.println(Word2[1][0][3]);
		
		
		
		
		
		
	}

}
