package javaprj.day05;

public class 실습2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 실습 )
//		1. 배열저장출력문제    (값 넣고  출력하기)
//		   2) 1차원배열 사용하기 -  예상 로또번호  저장하고 출력하기
		
		int[] lotto = new int [6];
		
		lotto[0] = 26;
		lotto[1] = 45;
		lotto[2] = 97;
		lotto[3] = 12;
		lotto[4] = 42;
		lotto[5] = 55;
		
		for (int i = 0; i < lotto.length; i++) {
			System.out.println(lotto[i]);
		}
		
		
	}

}
