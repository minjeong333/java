package javaprj.day05;

import java.util.Scanner;

public class 이용찬_배열예제 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//share  =>   
		
		/*
		 * 
		 *입력: repeat
		 *출력: numbers
		 *처리: front, middle, end
		 * 
		 * 
		 * 처리과정
		 * 1. 몇회 반복할지 결정 후 해당 횟수만큼 반복
		 * 	  1.1. -로 쪼개기
		 * 	  1.2. 쪼갠 것들을 numbers 배열에 넣기
		 * 2. numbers 배열의 행 갯수만큼 반복
		 *    2.1. -를 붙여서 front-middle-end 형태로 출력
		 */

		Scanner sc = new Scanner(System.in);
		
		System.out.println("입력할 전화번호 개수를 적으세요.");
		int repeat = sc.nextInt();
		int cnt = 0;
	 
		//전화번호들을 저장할 배열
		String[][] numbers = new String[repeat][3];
		
		//입력을 배열에 넣기
		System.out.println("<전화번호 입력>");
		loop: while(true) {
			
			System.out.println("전화번호를 입력하세요(ex: 000-0000-0000)");
			String input = sc.next();
			String[] nums = input.split("-");
			
			for(int i=0; i<numbers[cnt].length; i++) {
				numbers[cnt][i] = nums[i];
			}
			
			cnt ++;
			
			if(cnt == repeat) break loop;
			
		}
		
		sc.close();
		
		//출력
		System.out.println("<입력했던 전화번호들 출력>");
		for(int i=0; i<repeat; i++) {
			for(int j=0; j<numbers[i].length; j++) {
				System.out.print(numbers[i][j]+" ");
			}
			System.out.println();
		}
	}

}
