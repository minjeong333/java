package javaprj.day05;

import java.util.Scanner;

public class 배열실습_송주창 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][][] Previous_exams = {
				{	//2025년 기출문제
					{"보기 중 응집도가 가장 높은 것은?(기능, 교환, 우연, 시간)", "기능"},
					{"데이터를 중복시켜 성능을 향상시키기 위한 기법은?", "반정규화"},
					{"유닉스 또는 리눅스에서 자주 사용하는 명령어로 다음에 맞는 명령어는?"
							+ "(디렉터리의 내용을 목록으로 표시한다)", "ls"},
					{"사용자가 새로운 사이트에 가입하지 않고 평소에 이용하던 서비스의 계정으로 로그인할 수 있게 해주는 기술의 이름은?", "OAuth"},
					{"원격 접속과 관련된 보안 프로토콜이고, 포트번호가 22번인 이것의 이름은?", "SSH"}
				},
				
				{	//2024년 기출문제
					{"다음 내용이 나타내는 용어는?" + " IP나 ICMP의 특성을 악용하여 엄청난 양의 데이터를 한 사이트에 집중적으로 보냄으로써 네트워크의 일부를 불능 상태로 만드는 공격이다.", "스머프"},
					{"후보 키 중에서 선정된 기본키를 제외한 나머지 후보 키를 나타내는 용어는?", "대체키"},
					{"대칭키 알고리즘으로 1997년 NIST에서 DES를 대체하기 위해 생성된 알고리즘은?", "AES"},
					{"클래스나 객체들이 서로 상호작용하는 방법이나 책임 분배 방법을 정의하는 패턴인 이것은?(생성, 구조, 행위)", "행위"},
					{"공용 네트워크를 통해 사설 네트워크를 확장하고" + "사용자가 어디에 접속했는지를 추적하기 어렵게 만드는 이것은?", "VPN"}
					
				}
		};
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("원하는 년도를 선택하세요(2024, 2025)");
		int year = sc.nextInt();
		
		if(year == 2025) {
			System.out.println("원하는 번호를 입력하세요.(1 ~ 5)");
			int number = sc.nextInt();	//원하는 문제 번호 입력
			
			System.out.println(Previous_exams[0][number - 1][0]);
			String answer = sc.next();	//정답 입력
			
			if(answer.equals(Previous_exams[0][number-1][1])) {
				System.out.println("정답입니다.");
			}else {
				System.out.println("틀렸습니다.");
				System.out.println("정답은 " + Previous_exams[0][number - 1][1] + "입니다.");
			}
		}else if(year == 2024) {
			System.out.println("원하는 번호를 입력하세요.(1 ~ 5)");
			int number = sc.nextInt();	//원하는 문제 번호 입력
			
			
			System.out.println(Previous_exams[1][number - 1][0]);
			String answer = sc.next();	//정답 입력
			
			if(answer.equals(Previous_exams[1][number-1][1])) {
				System.out.println("정답입니다.");
			}else {
				System.out.println("틀렸습니다.");
				System.out.println("정답은 " + Previous_exams[1][number - 1][1] + "입니다.");
			}
		}
	}

}
